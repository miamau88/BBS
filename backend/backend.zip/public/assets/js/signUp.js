const frm = document.querySelector("#frm");
frm.addEventListener("submit", (e) => {
    console.log(frm.id)
    e.preventDefault()  // form에 있는 새로고침 기본기능을 막아줌 이걸넣으면
  if (frm.id.value == "") {
    alert("아이디를 입력하세요");
  } else if (frm.pw.value == "") {
    alert("비밀번호 입력하세요");
  } else if (frm.name.value == "") {
    alert("사용자를 입력하세요");
  } else {
    signCheck({userId:frm.id.value,userPw:frm.pw.value,userName:frm.name.value})
  }
});
async function signCheck(data) {
  try {
    const url = "http://localhost:5000/signUp"
    const fetchRes = await axios.post(url,data)
    //  fetch(`http://localhost:5000/signUp`, {
    //   method: "POST",
    //   headers: {
    //     "Content-Type": "application/json;charset=utf-8",
    //   },
    //   body: JSON.stringify(data),
    // });
    // const fetchRes2 = await fetchRes.json();
    console.log(fetchRes.data);
    const res = fetchRes.data
    if (res.status == "Sign success") {
      alert("등록성공");
      location.href = "/bbsList.html";
    } else {
      alert("등록실패");
    }
    await alert("test");
    await alert('ddd');
  } catch (err) {
    console.log(err);
    console.error(err);
  }
}

