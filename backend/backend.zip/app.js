const express = require("express");
const cors = require("cors");
const bbsRoute = require("./route/bbs");
const loginRoute = require("./route/login");
const path = require("path");
const moment = require("moment"); //설치한거
require("moment-timezone");
moment.tz.setDefault("Asia/Seoul");
const date = moment().format("YYYY-MM-DD HH:mm:ss");
console.log(date);
const http = require("http");
const fs = require("fs");
const db = require("./db.inc");
http.globalAgent.keepAlive = true;
const cron = require('node-cron');
// exports.moment = moment;

// const loginRoute = require("./routelogin");
const app = express();
app.use(cors());
app.use(express.json());
app.use("/", bbsRoute);
app.use("/", loginRoute);
//app.use("/login",route)
app.use(express.static(path.join(__dirname, "public"))); // 정적 파일 제공
//  app.get('/login',(req ,res) =>{
//   res.sendFile(path.join(__dirname, 'public/index.html'))
//    })

// app.get('/view',(req ,res) =>{
//   res.sendFile(path.join(__dirname, 'public/bbsView.html'))
// })
// 'C:\GitHub\BBS\backend\public'
// console.log(__dirname)


const cronData = () => {
  const Parsing = () => {
    try {
      const file = fs.createWriteStream("c:/test.json");
      const request = http.get(
        "http://158.247.198.231/0435.json",
        function (response) {
          response.pipe(file);
        }
      );
     
    } catch (err) {
      console.log(err);
    }
  };
  Parsing();
  const jsonData = async () => {
    try {
      const dataFile = fs.readFileSync("C:/test.json", "utf-8");
      const data = JSON.parse(dataFile);
      // console.log(data)
      return data
    } catch (err) {
      console.log(err);
    }
  };
  
  const dataResult = async () => {
    try {
      const res = await jsonData()
      const powerNum = res["ball"][5]
      const basicSum = res["def_ball_sum"]
      const powerDayNum = res["date_round"]
      const powerRoundNum = res["times"]
      const powerOE = res["pow_ball_oe"]
      const powerUO = res["pow_ball_unover"]
      const basicOE = res["def_ball_oe"]
      const basicUO = res["def_ball_unover"]
      const basicSize = res["def_ball_size"]
      const basicSection = res["def_ball_section"]
      // console.log(res)
      console.log("파워볼 회차 / 라운드", "/", powerDayNum, "/", powerRoundNum,)
      console.log("파워볼결과", powerNum, "/", powerOE, "/", powerUO)
      console.log("일반볼결과", basicSum, "/", basicOE, "/", basicUO, "/", basicSize, "/", basicSection)
      
      const querySelect = `select * from user order by signDate desc limit 1`;     
      const selectParam = [powerNum]
      db.query(querySelect,selectParam,function(err,rows,fields){        
        if (err) throw err;
        const rowId = rows[0].name
        console.log(rowId);     
         if (rowId !== rowId ) {
          const query = `insert into user (id,pw,name) value(?,?,?)`;
          const param = [powerNum, basicSum, powerDayNum]
          db.query(query, param, function (err, rows, fields) {
            if (err) throw err;
            // console.log(rows);
            // res.send({ status:"Sign success"});
          })
          }
     })      
    } catch (err) { console.log(err) }
  }
  dataResult()
}
function sleep(n){
	return new Promise( (resolve, reject)=>{
		setTimeout( ()=>{ resolve(true) }, n );
	} )
	
}
// var valid = cron.validate('*/53  * * * *');
// var invalid = cron.validate('*/53 4 * * * *');

// console.log(valid);
// console.log(invalid);

cron.schedule('*/58 4,9,14,19,24,29,34,39,44,49,54,59 * * * *', async () => {
// cron.schedule('*/20 * * * * *', async () => {
  console.log('58초마다 작업 실행')
  cronData() 
  await sleep(8000);  
  cronData() 
  // await sleep(15000);
  // cronData() 

  console.log(date);  
});


const port = 5000;

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
